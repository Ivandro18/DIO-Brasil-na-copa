# App Android Copa 2022

## API
https://digitalinnovationone.github.io/copa-2022-android/api.json
